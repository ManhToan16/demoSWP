
package Assignment;


public abstract class Staff {
    private String ID;
    private String name;
    private int age;
    private double coSal;
    private String dayIn;
    private String depart;
    private int dayOff;

    public Staff(String ID, String name, int age, double coSal, String dayIn, String depart, int dayOff) {
        this.ID = ID;
        this.name = name;
        this.age = age;
        this.coSal = coSal;
        this.dayIn = dayIn;
        this.depart = depart;
        this.dayOff = dayOff;
    }

    public String getID() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public double getCoSal() {
        return coSal;
    }

    public String getDayIn() {
        return dayIn;
    }

    public String getDepart() {
        return depart;
    }

    public int getDayOff() {
        return dayOff;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setCoSal(double coSal) {
        this.coSal = coSal;
    }

    public void setDayIn(String dayIn) {
        this.dayIn = dayIn;
    }

    public void setDepart(String depart) {
        this.depart = depart;
    }

    public void setDayOff(int dayOff) {
        this.dayOff = dayOff;
    }
    public abstract void displayInformation();

    @Override
    public String toString() {
        return "Staff{" + "ID=" + ID + ", name=" + name + ", age=" + age + ", coSal=" + coSal + ", dayIn=" + dayIn + ", depart=" + depart + ", dayOff=" + dayOff + '}';
    }

    
}
