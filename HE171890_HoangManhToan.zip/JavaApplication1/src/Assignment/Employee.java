
package Assignment;

import java.text.DecimalFormat;


public class Employee extends Staff implements ICalculator {
    private int OT;

    public Employee(int OT, String ID, String name, int age, double coSal, String dayIn, String depart, int dayOff) {
        super(ID, name, age, coSal, dayIn, depart, dayOff);
        this.OT = OT;
    }

    public int getOT() {
        return OT;
    }

    public void setOT(int OT) {
        this.OT = OT;
    }
    @Override
    public double calculateSalary(){
        return this.getCoSal()*3000000+this.getOT()*200000;
    }
    @Override
    public void displayInformation(){
        System.out.print(this.getID());
        for(int i=0;i<(16-this.getID().length());i++){
            System.out.print(" ");
        }
        System.out.print("| ");
        System.out.print(this.getName());
        for(int i=0;i<(22-this.getName().length());i++){
            System.out.print(" ");
        }
        System.out.print("| ");
        String tuoi = String.valueOf(this.getAge());
        System.out.print(this.getAge());
        for(int i=0;i<(10-tuoi.length());i++){
            System.out.print(" ");
        }
        System.out.print("| ");
        System.out.print(this.getCoSal());
        String hesoluong = String.valueOf(this.getCoSal());
        for(int i=0;i<(14-hesoluong.length());i++){
            System.out.print(" ");
        }
        System.out.print("| ");
        System.out.print(this.getDayIn());
        for(int i=0;i<(18-this.getDayIn().length());i++){
            System.out.print(" ");
        }
        System.out.print("| ");
        System.out.print(this.getDayOff());
        String dayoff = String.valueOf(this.getDayOff());
        for(int i=0;i<(18-dayoff.length());i++){
            System.out.print(" ");
        }
        System.out.print("| ");
        System.out.print(this.getDepart());
        for(int i=0;i<(22-this.getDepart().length());i++){
            System.out.print(" ");
        }
        System.out.print("| ");
        System.out.print(this.OT);
        String Overtime = String.valueOf(OT);
        for(int i=0;i<(26-Overtime.length());i++){
            System.out.print(" ");
        }
        System.out.print("| ");
        DecimalFormat formatter = new DecimalFormat("###,###,###.00");
        System.out.println(formatter.format(this.calculateSalary()));
    }
}
