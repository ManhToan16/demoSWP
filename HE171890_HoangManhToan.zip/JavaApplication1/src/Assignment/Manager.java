
package Assignment;

import java.text.DecimalFormat;


public class Manager extends Staff implements ICalculator {
    private String title;

    public Manager(String title, String ID, String name, int age, double coSal, String dayIn, String depart, int dayOff) {
        super(ID, name, age, coSal, dayIn, depart, dayOff);
        this.title = title;
    }
    @Override
    public double calculateSalary(){
        double cal = 0d;
        if(title.equalsIgnoreCase("Business Leader")){
            cal = 8000000;
        }
        if(title.equalsIgnoreCase("Project Leader")){
            cal = 5000000;
        }
        if(title.equalsIgnoreCase("Technical Leader")){
            cal = 6000000;
        }
        return this.getCoSal()*5000000+cal;
    }
    @Override
    public void displayInformation(){
        System.out.print(this.getID());
        for(int i=0;i<(16-this.getID().length());i++){
            System.out.print(" ");
        }
        System.out.print("| ");
        System.out.print(this.getName());
        for(int i=0;i<(22-this.getName().length());i++){
            System.out.print(" ");
        }
        System.out.print("| ");
        String tuoi = String.valueOf(this.getAge());
        System.out.print(this.getAge());
        for(int i=0;i<(10-tuoi.length());i++){
            System.out.print(" ");
        }
        System.out.print("| ");
        System.out.print(this.getCoSal());
        String hesoluong = String.valueOf(this.getCoSal());
        for(int i=0;i<(14-hesoluong.length());i++){
            System.out.print(" ");
        }
        System.out.print("| ");
        System.out.print(this.getDayIn());
        for(int i=0;i<(18-this.getDayIn().length());i++){
            System.out.print(" ");
        }
        System.out.print("| ");
        System.out.print(this.getDayOff());
        String dayoff = String.valueOf(this.getDayOff());
        for(int i=0;i<(18-dayoff.length());i++){
            System.out.print(" ");
        }
        System.out.print("| ");
        System.out.print(this.getDepart());
        for(int i=0;i<(22-this.getDepart().length());i++){
            System.out.print(" ");
        }
        System.out.print("| ");
        System.out.print(this.title);
        for(int i=0;i<(26-title.length());i++){
            System.out.print(" ");
        }
        System.out.print("| ");
        DecimalFormat formatter = new DecimalFormat("###,###,###.00");
        System.out.println(formatter.format(this.calculateSalary()));
    }
    
}
