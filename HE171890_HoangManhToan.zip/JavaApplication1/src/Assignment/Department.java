
package Assignment;


public class Department {
    private String departCode;
    private String departName;
    private int numOfEmp;

    public Department(String departCode, String departName, int numOfEmp) {
        this.departCode = departCode;
        this.departName = departName;
        this.numOfEmp = numOfEmp;
    }
    
    
    public String getDepartCode() {
        return departCode;
    }

    public String getDepartName() {
        return departName;
    }

    public int getNumOfEmp() {
        return numOfEmp;
    }

    public void setDepartCode(String departCode) {
        this.departCode = departCode;
    }

    public void setDepartName(String departName) {
        this.departName = departName;
    }

    public void setNumOfEmp(int numOfEmp) {
        this.numOfEmp = numOfEmp;
    }

    @Override
    public String toString() {
        String space1 = "";
        String space2 = "";
        for(int i=0;i<(12-departCode.length());i++){
            space1+=" ";
        }
        for(int i=0;i<(26-departName.length());i++){
            space2+=" ";
        }
        return departCode + space1 +"| "+ departName + space2 + "| "+ numOfEmp;
    }
    
}
