
package Assignment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import java.util.List;


public class EmployeeManager {
     public static void Menu(){
        System.out.println("1. Hiển thị danh sách nhân viên hiện có trong công ty.");
        System.out.println("2. Hiển thị các bộ phận trong công ty.");
        System.out.println("3. Hiển thị các nhân viên theo từng bộ phận.");
        System.out.println("4. Thêm nhân viên mới vào công ty");
        System.out.println("5. Tìm kiếm thông tin nhân viên theo tên hoặc mã nhân viên.");
        System.out.println("6. Hiển thị bảng lương của nhân viên theo thứ tự giảm dần.");
        System.out.println("7. Hiển thị bảng lương của nhân viên theo thứ tự tăng dần.");
        System.out.println("0. Thoát chương trình.");
        System.out.print("Lựa chọn của bạn: ");
    }

    
    public static void main(String[] args) {
        
        Staff e1 = new Manager("Technical Leader","HE171890","Hoang Manh Toan",20,1.0,"16/3/2003","Công nghệ thông tin",4);
        Staff e2 = new Manager("Business Leader","HE162003","Nguyen Lan Anh",20,2.5,"26/08/2003","Công nghệ thông tin",3);
        Staff e3 = new Employee(10,"HC001","Nguyen Van A",21,1.5,"1/1/2022", "Hành chính nhân sự",4);
        Staff e4 = new Employee(10,"MKT001","Nguyen Van B",22,4.0,"1/1/2022", "Marketing",4);
        
        ArrayList<Staff> staff = new ArrayList();
        staff.add(e1);
        staff.add(e2);
        staff.add(e3);
        staff.add(e4);
        
        ArrayList<Department> department= new ArrayList();
        Department HC = new Department("HC","Hành chính nhân sự",1);
        Department IT = new Department("IT","Công nghệ thông tin",2);
        Department MKT = new Department("MKT","Marketing",1);
        department.add(IT);
        department.add(HC);
        department.add(MKT);
        
        Scanner sc = new Scanner(System.in);
        int choice;
        do{
            Menu();
            choice  = sc.nextInt();
            sc.nextLine();
            switch(choice){
                case 1:
                    System.out.println("Mã nhân viên    | Tên nhân viên         | Tuổi      | HS Lương      | Ngày vào làm      | Ngày nghỉ phép    | Bộ phận               | Số giờ làm thêm/Chức vụ   | Lương");
                    for(int i=0;i<staff.size();i++){
                        staff.get(i).displayInformation();
                    }
                    break;
                case 2:
                    System.out.println("Mã bộ phận  | Tên bộ phận               | Số lượng nhân viên hiện tại");
                    for(int i=0;i<department.size();i++){
                        System.out.println(department.get(i).toString());
                    }
                    break;
                case 3:
                    System.out.println("Hành chính nhân sự");
                    System.out.println("-------------------------------");
                    System.out.println("Mã nhân viên    | Tên nhân viên         | Tuổi      | HS Lương      | Ngày vào làm      | Ngày nghỉ phép    | Bộ phận               | Số giờ làm thêm/Chức vụ   | Lương");

                    for(int i=0;i<staff.size();i++){
                        if(staff.get(i).getDepart().equalsIgnoreCase("Hành chính nhân sự")){;
                        staff.get(i).displayInformation();
                        }
                    }
                    System.out.println();
                    System.out.println("Công nghệ thông tin");
                    System.out.println("-------------------------------");
                    System.out.println("Mã nhân viên    | Tên nhân viên         | Tuổi      | HS Lương      | Ngày vào làm      | Ngày nghỉ phép    | Bộ phận               | Số giờ làm thêm/Chức vụ   | Lương");

                    for(int i=0;i<staff.size();i++){
                        if(staff.get(i).getDepart().equalsIgnoreCase("Công nghệ thông tin")){;
                        staff.get(i).displayInformation();
                        }
                    }
                    System.out.println();
                    System.out.println("Marketing");
                    System.out.println("-------------------------------");
                    System.out.println("Mã nhân viên    | Tên nhân viên         | Tuổi      | HS Lương      | Ngày vào làm      | Ngày nghỉ phép    | Bộ phận               | Số giờ làm thêm/Chức vụ   | Lương");

                    for(int i=0;i<staff.size();i++){
                        if(staff.get(i).getDepart().equalsIgnoreCase("Marketing")){;
                        staff.get(i).displayInformation();
                        }
                    }
                    System.out.println();
                    break;
                case 4:
                    System.out.println("1. Thêm nhân viên thông thường");
                    System.out.println("2. Thêm nhân viên là cấp quản lý (có thêm chức vụ)");
                    int opt = 0;
                    boolean check;
                    do{
                        try{
                            System.out.print("Bạn chọn: ");
                            opt = sc.nextInt();
                            check = true;
                        }catch(Exception e){
                            System.out.println("Vui lòng nhập lại!");
                            check = false;
                        }
                        finally{
                        sc.nextLine();
                        }
                    }while(check == false || (opt>2 || opt <1) );
                    System.out.print("Nhập mã nhân viên: ");
                    String manhanvien = sc.nextLine();
                    System.out.print("Nhập tên nhân viên: ");
                    String tennhanvien = sc.nextLine();
                    System.out.print("Nhập tuổi nhân viên: ");
                    int tuoinhanvien = sc.nextInt();
                    System.out.print("Nhập hệ số lương của nhân viên: ");
                    double hesoluong = sc.nextDouble();
                    sc.nextLine();
                    System.out.print("Nhập ngày vào làm của nhân viên: ");
                    String ngayvaolam = sc.nextLine();
                    System.out.print("Nhập số ngày nghỉ phép của nhân viên: ");
                    int nghiphep = sc.nextInt();
                    sc.nextLine();
                    System.out.println("1. HC - Hành chính nhân sự");
                    System.out.println("2. IT - Công nghệ thông tin");
                    System.out.println("3. MKT - Marketing");
                    System.out.print("Bạn chọn bộ phận: ");
                    String bophan = sc.nextLine();
                    if(bophan.equals("1")){
                        HC.setNumOfEmp(HC.getNumOfEmp()+1); 
                        bophan = "Hành chính nhân sự";
                    }
                    if(bophan.equals("2")){
                        IT.setNumOfEmp(IT.getNumOfEmp()+1);
                        bophan = "Công nghệ thông tin";
                    }
                    if(bophan.equals("3")){
                        MKT.setNumOfEmp(MKT.getNumOfEmp()+1);
                        bophan = "Marketing";
                    }
                    if(opt == 1){
                        System.out.print("Nhập số giờ làm thêm: ");
                        int lamthem = sc.nextInt();
                        sc.nextLine();
                        Staff tmp = new Employee(lamthem, manhanvien, tennhanvien, tuoinhanvien, hesoluong, ngayvaolam, bophan, nghiphep);
                        if(staff.add(tmp)){
                            System.out.println("Đã thêm thành công!\n");
                        }
                    }
                    if(opt == 2){
                        System.out.println("Chức danh:");
                        System.out.println("1. Business Leader");
                        System.out.println("2. Project Leader");
                        System.out.println("3. Technical Leader");
                        System.out.print("Nhập chức danh: ");
                        String chucdanh = sc.nextLine();
                        if(chucdanh.equals("1")){
                            chucdanh = "Business Leader";
                        }
                        if(chucdanh.equals("2")){
                            chucdanh = "Project Leader";
                        }
                        if(chucdanh.equals("3")){
                            chucdanh = "Technical Leader";
                        }
                        Staff tmp = new Manager(chucdanh, manhanvien, tennhanvien, tuoinhanvien, hesoluong, ngayvaolam, bophan, nghiphep);
                        if(staff.add(tmp)){
                            System.out.println("Đã thêm thành công!");
                        }
                    }
                    break;
                case 5:
                    System.out.println("1. Tìm nhân viên bằng tên:");
                    System.out.println("2. Tìm nhân viên bằng mã nhân viên:");
                    System.out.print("Bạn chọn: ");
                    opt = sc.nextInt();
                    sc.nextLine();
                    System.out.println();
                    if(opt == 1){
                        System.out.print("Nhập tên nhân viên cần tìm: ");
                        String tencantim = sc.nextLine();
                        System.out.println("Mã nhân viên    | Tên nhân viên         | Tuổi      | HS Lương      | Ngày vào làm      | Ngày nghỉ phép    | Bộ phận               | Số giờ làm thêm/Chức vụ   | Lương");
                        for(int i=0;i<staff.size();i++){
                            if(staff.get(i).getName().toLowerCase().contains(tencantim.toLowerCase())){
                                staff.get(i).displayInformation();
                            }
                        }
                    }
                    if(opt == 2){
                        System.out.print("Nhập mã nhân viên cần tìm: ");
                        String macantim = sc.nextLine();
                        System.out.println("Mã nhân viên    | Tên nhân viên         | Tuổi      | HS Lương      | Ngày vào làm      | Ngày nghỉ phép    | Bộ phận               | Số giờ làm thêm/Chức vụ   | Lương");
                        for(int i=0;i<staff.size();i++){
                            if(staff.get(i).getID().toLowerCase().contains(macantim.toLowerCase())){
                                staff.get(i).displayInformation();
                            }
                        }
                    }
                    break;
                case 6:
                    //sắp xếp bằng Collections sorting
                    Collections.sort(staff, new Comparator<Staff>(){
                        @Override
                        public int compare(Staff s1, Staff s2){
                            double sal1=0d;
                            double sal2=0d;
                            //downcasting để gọi được hàm calculateSalary()
                            if(s1 instanceof Employee && s2 instanceof Employee){
                                sal1 = ((Employee)s1).calculateSalary();
                                sal2 = ((Employee)s2).calculateSalary();
                            }else if(s1 instanceof Manager && s2 instanceof Manager){
                                sal1 = ((Manager)s1).calculateSalary();
                                sal2 = ((Manager)s2).calculateSalary();
                            }else if(s1 instanceof Employee && s2 instanceof Manager){
                                sal1 = ((Employee)s1).calculateSalary();
                                sal2 = ((Manager)s2).calculateSalary();
                            }else {
                                sal1 = ((Manager)s1).calculateSalary();
                                sal2 = ((Employee)s2).calculateSalary();
                            }
                            return sal1 < sal2 ? 1 : -1;
                        }
                    });
                    System.out.println("Mã nhân viên    | Tên nhân viên         | Tuổi      | HS Lương      | Ngày vào làm      | Ngày nghỉ phép    | Bộ phận               | Số giờ làm thêm/Chức vụ   | Lương");
                    for(int i=0;i<staff.size();i++){
                        staff.get(i).displayInformation();
                    }
                    break;
                case 7:
                    //sắp xếp bằng Collections sorting
                    Collections.sort(staff, new Comparator<Staff>(){
                        @Override
                        public int compare(Staff s1, Staff s2){
                            double sal1=0d;
                            double sal2=0d;
                            //downcasting để gọi được hàm calculateSalary()
                            if(s1 instanceof Employee && s2 instanceof Employee){
                                sal1 = ((Employee)s1).calculateSalary();
                                sal2 = ((Employee)s2).calculateSalary();
                            }else if(s1 instanceof Manager && s2 instanceof Manager){
                                sal1 = ((Manager)s1).calculateSalary();
                                sal2 = ((Manager)s2).calculateSalary();
                            }else if(s1 instanceof Employee && s2 instanceof Manager){
                                sal1 = ((Employee)s1).calculateSalary();
                                sal2 = ((Manager)s2).calculateSalary();
                            }else {
                                sal1 = ((Manager)s1).calculateSalary();
                                sal2 = ((Employee)s2).calculateSalary();
                            }
                            return sal1 > sal2 ? 1 : -1;
                        }
                    });
                    System.out.println("Mã nhân viên    | Tên nhân viên         | Tuổi      | HS Lương      | Ngày vào làm      | Ngày nghỉ phép    | Bộ phận               | Số giờ làm thêm/Chức vụ   | Lương");
                    for(int i=0;i<staff.size();i++){
                        staff.get(i).displayInformation();
                    }
            } 
        }while(choice != 0);
    }
   
    
}
